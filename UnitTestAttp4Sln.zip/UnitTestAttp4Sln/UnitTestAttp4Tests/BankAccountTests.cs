﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankApp;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UnitTestBank;

namespace BankApp.Tests
{ 
    [TestClass()]
    public class BankAccountTests
    {
        [TestMethod()]
        public void DebitTest()
        {
            //Create new instance of Debit Test
            BankAccount target = new BankAccount("John McGinn", 50);
            //set test amount
            double testAmount = 20;
            //test value with method
            target.Debit(testAmount);
            //Declare actual result
            double actual = target.Balance;
            //Declare expected
            double expected = 30;
            //Assert that results are equal
            Assert.AreEqual(actual, expected);
        }

        [TestMethod()]
        public void CreditTest()
        {
            //Create new instance of Debit Test
            BankAccount target = new BankAccount("Paul Mason", 50);
            //set test amount
            double testAmount = 20;
            //test value with method
            target.Credit(testAmount);
            //Declare actual result
            double actual = target.Balance;
            //Declare expected
            double expected = 70;
            //Assert that results are equal
            Assert.AreEqual(actual, expected);
        }
        
        [TestMethod()]
        public void FreezeAccountTest()
        {
            //Initialize to an appropriate value
            BankAccount target = new BankAccount("Shane Finnegan", 35.50);
            target.FreezeAccount();

            //Initailise to false so that crediting can happen
            bool creditAccount = false; 
                
                // Try to credit account
                try
                {
                    target.Credit(10.00);
                }
                //Should catch an exception within the method
                catch (System.Exception)
                {
                    // Threw exception. FreezeAccount worked correctly: Pass test. 
                    creditAccount = true;
                }

            // Assert fails if 'creditAccount' condition is false. Fail test.
            Assert.IsTrue(creditAccount, "Was able to credit account.");
        }
        
        [TestMethod()]
        public void CheckCustomerUpdates ()
        {
            //Create an instance
            BankAccount check = new BankAccount("Nick Brennan", 50);
            //test name
            string clientName = "Andrew Mclean";
            //pass to method
            check.UpdateCustomerDetails(clientName);
            //Check actual result
            string actual = check.CustomerName;

            Assert.AreEqual(actual, clientName);
        }
    }//close class

    [TestClass()]
    public class CustomerTest
    {
    [TestMethod()]
        public void CountryTest()
        {
            //Create new instance of class
            Customer target = new Customer("Ireland", 22);
            //Test Country
            string testCountry = "France";
            //pass to the method
            target.UpdateCountry(testCountry);
            //Actual results
            string actual = target.CustomerCountry;
            //Assert that test country is validated through test
            Assert.AreEqual(testCountry, actual);
        }

    [TestMethod()]
    public void ValidateAge()
    {
        Customer target = new Customer("Germany", 25);
        //Test age method
        int testAge = 19;
        //pass to method
        target.UpdateAge(testAge);
        //Actual Results
        int actual = target.CustomerAge;
        Assert.AreEqual(19, actual);
    }

    }//Close Class
}
