﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankApp;
using UnitTestBank;

namespace BankApp
{
    /// <summary> 
    /// Bank Account demo class. 
    /// </summary> 
    public class BankAccount
    {
        private string m_customerName;
        private double m_balance;
        private bool m_frozen = false;

        public BankAccount(string customerName, double balance)
        {
            m_customerName = customerName;
            m_balance = balance;
        }


        public string CustomerName
        {
            get { return m_customerName; }
            
        }

        public double Balance
        {
            get { return m_balance; }
        }

        /// <summary>
        /// Debit (decrease) the account  with a given amount
        /// </summary>
        /// <param name="amount"></param>
        public void Debit(double amount)
        {
            if (m_frozen)
            {
                throw new Exception("Account frozen");
            }

            if (amount > m_balance)
            {
                throw new ArgumentOutOfRangeException("amount");
            }

            if (amount < 0)
            {
                throw new ArgumentOutOfRangeException("amount");
            }

            m_balance -= amount;
        }

        /// <summary>
        /// Credit (Increase) the account  with a given amount
        /// </summary>
        /// <param name="amount"></param>
        public void Credit(double amount)
        {
            if (m_frozen)
            {
                throw new Exception("Account frozen");
            }

            if (amount < 0)
            {
                throw new ArgumentOutOfRangeException("amount");
            }

            m_balance += amount;
        }

        //Add Method to update Customer details
        public void UpdateCustomerDetails(string name)
        {
            if (name == "Mark Furlong")
            {
                throw new Exception("Account is Frozen");
            }
            m_customerName = name;
        }

        /// <summary>
        /// If account is Frozen, then no activity should be allowed
        /// </summary>
        public void FreezeAccount()
        {
            m_frozen = true;
        }

        public void UnfreezeAccount()
        {
            m_frozen = false;
        }
        public static void Main()
        {
            BankAccount ba = new BankAccount("Larry Mullen", 11.99);

            ba.Credit(5.77);
            ba.Debit(11.22);
            ba.UpdateCustomerDetails("David Furlong");

            Console.WriteLine("Current balance is ${0}", ba.Balance);
            Console.WriteLine("Customer name is " + ba.CustomerName);


            Customer fr = new Customer("Ireland", 33);
            fr.UpdateCountry("Germany");
            fr.UpdateAge(32);
            Console.WriteLine("The customer is from " + fr.CustomerCountry);
            Console.WriteLine("The customer is aged {0} ", fr.CustomerAge);
            Console.Read();
        }
    } //Close class
}

