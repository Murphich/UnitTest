﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTestBank
{
    public class Customer
    {
        //initiate variables
        private string customerCountry;
        private int customerAge;
        
        //Initialise 2 arg cons
        public Customer(string Country, int Age)
        {
            customerCountry = Country;
            customerAge = Age;
        }

         //Set get methods
         //public string CustomerCountry { get; set;}
         //public int CustomerAge { get; set; }
         
        public string CustomerCountry
        {
            get { return customerCountry; }
            set { customerCountry = value; }
        }
        
        public int CustomerAge
        {
            get { return customerAge; }
            set { customerAge = value; }
        }
        
        //Update Country
        public void UpdateCountry(string country)
        {
            if (country == "Ireland")
            {
                throw new Exception("This is International banking only");
            }
            //check which value is being passed
            customerCountry = country;
        }

        //Update Age
        public void UpdateAge(int age)
        {
            if (age < 18)
            {
                throw new Exception("You cant bank with us until your 18");
            }
            customerAge = age;
        }
    }
}
